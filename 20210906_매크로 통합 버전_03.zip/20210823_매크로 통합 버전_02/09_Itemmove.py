import pyautogui as pag
import time
import random


def left_itemunequip():
    time.sleep(random.uniform(4.55, 5.65))
    pag.click(random.uniform(852, 872), random.uniform(46, 64), 1, random.uniform(0.1, 0.3))
    # 장비창 열기
    time.sleep(random.uniform(1, 2))
    pag.click(random.uniform(26, 65), random.uniform(330, 360), 2, random.uniform(0.1, 0.3))
    # 무기 해제 
    time.sleep(random.uniform(0.55, 1.19))
    pag.click(random.uniform(26, 65), random.uniform(400, 430), 2, random.uniform(0.1, 0.3))
    # 투구 해제
    time.sleep(random.uniform(0.55, 1.19))
    pag.click(random.uniform(26, 65), random.uniform(470, 500), 2, random.uniform(0.1, 0.3))
    # 갑옷 해제
    time.sleep(random.uniform(0.55, 1.19))
    pag.click(random.uniform(26, 65), random.uniform(540, 570), 2, random.uniform(0.1, 0.3))
    # 장갑 해제
    time.sleep(random.uniform(0.55, 1.19))
    pag.click(random.uniform(26, 65), random.uniform(610, 640), 2, random.uniform(0.1, 0.3))
    # 신발 해제
    time.sleep(random.uniform(0.55, 1.19))
    pag.click(random.uniform(26, 65), random.uniform(680, 710), 2, random.uniform(0.1, 0.3))
    # 망토 해제
    time.sleep(random.uniform(0.55, 1.19))
    pag.click(random.uniform(530, 560), random.uniform(330, 360), 2, random.uniform(0.1, 0.3))
    # 목걸이 해제
    time.sleep(random.uniform(0.55, 1.19))
    pag.click(random.uniform(530, 560), random.uniform(400, 430), 2, random.uniform(0.1, 0.3))
    # 귀걸이 해제
    time.sleep(random.uniform(0.55, 1.19))
    pag.click(random.uniform(530, 560), random.uniform(470, 500), 2, random.uniform(0.1, 0.3))
    # 팔찌 해제
    time.sleep(random.uniform(0.55, 1.19))
    pag.click(random.uniform(530, 560), random.uniform(540, 570), 2, random.uniform(0.1, 0.3))
    # 반지 해제
    time.sleep(random.uniform(0.55, 1.19))
    pag.click(random.uniform(530, 560), random.uniform(610, 640), 2, random.uniform(0.1, 0.3))
    # 벨트 해제
    time.sleep(random.uniform(0.55, 1.19))
    pag.click(random.uniform(530, 560), random.uniform(680, 700), 2, random.uniform(0.1, 0.3))
    # 호른 해제
    time.sleep(random.uniform(0.55, 1.19))
    pag.click(random.uniform(455, 490), random.uniform(670, 700), 2, random.uniform(0.1, 0.3))
    # 문장 해제
    time.sleep(random.uniform(0.55, 1.19))
    pag.click(random.uniform(455, 490), random.uniform(600, 630), 2, random.uniform(0.1, 0.3))
    # 완장 해제
    time.sleep(random.uniform(0.55, 1.19))
    pag.click(random.uniform(914, 939), random.uniform(45, 63), 1, random.uniform(0.1, 0.3))
    # 장비창 나가기
    time.sleep(random.uniform(3.1, 4.99))
    pag.click(random.uniform(660, 690), random.uniform(965, 990), 1, random.uniform(0.3, 0.6))
    # 창고 가기
    time.sleep(random.uniform(15.11, 16.99))
    pag.click(random.uniform(600, 650), random.uniform(140, 180), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(670, 720), random.uniform(140, 180), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(740, 790), random.uniform(140, 180), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(810, 860), random.uniform(140, 180), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(880, 930), random.uniform(140, 180), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(600, 650), random.uniform(210, 250), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(670, 720), random.uniform(210, 250), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(740, 790), random.uniform(210, 250), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(810, 860), random.uniform(210, 250), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(880, 930), random.uniform(210, 250), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(600, 650), random.uniform(280, 320), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(670, 720), random.uniform(280, 320), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(740, 790), random.uniform(280, 320), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(810, 860), random.uniform(280, 320), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(880, 930), random.uniform(280, 320), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(600, 650), random.uniform(350, 390), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(670, 720), random.uniform(350, 390), 1, random.uniform(0.3, 0.6))
    # 아이템 창고 보관
    time.sleep(random.uniform(3.55, 4.12))
    pag.click(random.uniform(840, 930), random.uniform(995, 1015), 1, random.uniform(0.3, 0.6))
    # 보관 버튼
    time.sleep(random.uniform(3.55, 4.12))
    pag.click(random.uniform(914, 939), random.uniform(45, 63), 1, random.uniform(0.3, 0.6))
    # 창고 나가기
    time.sleep(random.uniform(4.5, 5.5))

def left_itemequip():
    time.sleep(random.uniform(40, 41))
    pag.click(random.uniform(660, 690), random.uniform(965, 990), 1, random.uniform(0.3, 0.6))
    # 창고가기
    time.sleep(random.uniform(10, 11))
    pag.click(random.uniform(30, 70), random.uniform(220, 260), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(100, 140), random.uniform(220, 260), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(170, 210), random.uniform(220, 260), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(240, 280), random.uniform(220, 260), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(30, 70), random.uniform(290, 330), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(100, 140), random.uniform(290, 330), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(170, 210), random.uniform(290, 330), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(240, 280), random.uniform(290, 330), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(30, 70), random.uniform(360, 400), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(100, 140), random.uniform(360, 400), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(170, 210), random.uniform(360, 400), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(240, 280), random.uniform(360, 400), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(30, 70), random.uniform(430, 470), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(100, 140), random.uniform(430, 470), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(170, 210), random.uniform(430, 470), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(240, 280), random.uniform(430, 470), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(30, 70), random.uniform(500, 540), 1, random.uniform(0.3, 0.6))
    # 창고 아이템 클릭
    time.sleep(random.uniform(1.55, 2.12))
    pag.click(random.uniform(190, 285), random.uniform(995, 1015), 1, random.uniform(0.3, 0.6))
    # 꺼내기 버튼 
    time.sleep(random.uniform(1.55, 2.12))
    pag.click(random.uniform(914, 939), random.uniform(45, 63), 1, random.uniform(0.1, 0.3))
    # 나가기 버튼
    time.sleep(random.uniform(1.001, 1.55))
    pag.click(random.uniform(852, 872), random.uniform(46, 64), 1, random.uniform(0.1, 0.3))
    # 장비창 열기
    time.sleep(random.uniform(3.001, 4.005))
    pag.click(random.uniform(840, 930), random.uniform(1000, 1015), 1, 0.5)
    # 자동 장착
    time.sleep(random.uniform(1.55, 2.12))
    pag.click(random.uniform(914, 939), random.uniform(45, 63), 1, random.uniform(0.1, 0.3))
    # 나가기 버튼
    time.sleep(random.uniform(4.5, 5.5))

def right_itemunequip():
    time.sleep(random.uniform(4.55, 5.65))
    pag.click(random.uniform(852+960, 872+960), random.uniform(46, 64), 1, random.uniform(0.1, 0.3))
    # 장비창 열기
    time.sleep(random.uniform(1, 2))
    pag.click(random.uniform(26+960, 65+960), random.uniform(330, 360), 2, random.uniform(0.1, 0.3))
    # 무기 해제 
    time.sleep(random.uniform(0.55, 1.19))
    pag.click(random.uniform(26+960, 65+960), random.uniform(400, 430), 2, random.uniform(0.1, 0.3))
    # 투구 해제
    time.sleep(random.uniform(0.55, 1.19))
    pag.click(random.uniform(26+960, 65+960), random.uniform(470, 500), 2, random.uniform(0.1, 0.3))
    # 갑옷 해제
    time.sleep(random.uniform(0.55, 1.19))
    pag.click(random.uniform(26+960, 65+960), random.uniform(540, 570), 2, random.uniform(0.1, 0.3))
    # 장갑 해제
    time.sleep(random.uniform(0.55, 1.19))
    pag.click(random.uniform(26+960, 65+960), random.uniform(610, 640), 2, random.uniform(0.1, 0.3))
    # 신발 해제
    time.sleep(random.uniform(0.55, 1.19))
    pag.click(random.uniform(26+960, 65+960), random.uniform(680, 710), 2, random.uniform(0.1, 0.3))
    # 망토 해제
    time.sleep(random.uniform(0.55, 1.19))
    pag.click(random.uniform(530+960, 56+9600), random.uniform(330, 360), 2, random.uniform(0.1, 0.3))
    # 목걸이 해제
    time.sleep(random.uniform(0.55, 1.19))
    pag.click(random.uniform(530+960, 560+960), random.uniform(400, 430), 2, random.uniform(0.1, 0.3))
    # 귀걸이 해제
    time.sleep(random.uniform(0.55, 1.19))
    pag.click(random.uniform(530+960, 560+960), random.uniform(470, 500), 2, random.uniform(0.1, 0.3))
    # 팔찌 해제
    time.sleep(random.uniform(0.55, 1.19))
    pag.click(random.uniform(530+960, 560+960), random.uniform(540, 570), 2, random.uniform(0.1, 0.3))
    # 반지 해제
    time.sleep(random.uniform(0.55, 1.19))
    pag.click(random.uniform(530+960, 560+960), random.uniform(610, 640), 2, random.uniform(0.1, 0.3))
    # 벨트 해제
    time.sleep(random.uniform(0.55, 1.19))
    pag.click(random.uniform(530+960, 560+960), random.uniform(680, 700), 2, random.uniform(0.1, 0.3))
    # 호른 해제
    time.sleep(random.uniform(0.55, 1.19))
    pag.click(random.uniform(455+960, 490+960), random.uniform(670, 700), 2, random.uniform(0.1, 0.3))
    # 문장 해제
    time.sleep(random.uniform(0.55, 1.19))
    pag.click(random.uniform(455+960, 490+960), random.uniform(600, 630), 2, random.uniform(0.1, 0.3))
    # 완장 해제
    time.sleep(random.uniform(0.55, 1.19))
    pag.click(random.uniform(914+960, 939+960), random.uniform(45, 63), 1, random.uniform(0.1, 0.3))
    # 장비창 나가기
    time.sleep(random.uniform(3.1, 4.99))
    pag.click(random.uniform(660+960, 690+960), random.uniform(965, 990), 1, random.uniform(0.3, 0.6))
    # 창고 가기
    time.sleep(random.uniform(15.11, 16.99))
    pag.click(random.uniform(600+960, 650+960), random.uniform(140, 180), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(670+960, 720+960), random.uniform(140, 180), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(740+960, 790+960), random.uniform(140, 180), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(810+960, 860+960), random.uniform(140, 180), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(880+960, 930+960), random.uniform(140, 180), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(600+960, 650+960), random.uniform(210, 250), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(670+960, 720+960), random.uniform(210, 250), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(740+960, 790+960), random.uniform(210, 250), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(810+960, 860+960), random.uniform(210, 250), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(880+960, 930+960), random.uniform(210, 250), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(600+960, 650+960), random.uniform(280, 320), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(670+960, 720+960), random.uniform(280, 320), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(740+960, 790+960), random.uniform(280, 320), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(810+960, 860+960), random.uniform(280, 320), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(880+960, 930+960), random.uniform(280, 320), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(600+960, 650+960), random.uniform(350, 390), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(670+960, 720+960), random.uniform(350, 390), 1, random.uniform(0.3, 0.6))
    # 아이템 창고 보관
    time.sleep(random.uniform(3.55, 4.12))
    pag.click(random.uniform(840+960, 930+960), random.uniform(995, 1015), 1, random.uniform(0.3, 0.6))
    # 보관 버튼
    time.sleep(random.uniform(3.55, 4.12))
    pag.click(random.uniform(914+960, 939+960), random.uniform(45, 63), 1, random.uniform(0.3, 0.6))
    # 창고 나가기
    time.sleep(random.uniform(4.5, 5.5))

def right_itemequip():
    time.sleep(random.uniform(40, 41))
    pag.click(random.uniform(660+960, 690+960), random.uniform(965, 990), 1, random.uniform(0.3, 0.6))
    # 창고가기
    time.sleep(random.uniform(10, 11))
    pag.click(random.uniform(30,+960, 70+960), random.uniform(220, 260), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(100+960, 140+960), random.uniform(220, 260), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(170+960, 210+960), random.uniform(220, 260), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(240+960, 280+960), random.uniform(220, 260), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(30+960, 70+960), random.uniform(290, 330), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(100+960, 140+960), random.uniform(290, 330), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(170+960, 210+960), random.uniform(290, 330), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(240+960, 280+960), random.uniform(290, 330), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(30+960, 70+960), random.uniform(360, 400), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(100+960, 140+960), random.uniform(360, 400), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(170+960, 210+960), random.uniform(360, 400), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(240+960, 280+960), random.uniform(360, 400), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(30+960, 70+960), random.uniform(430, 470), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(100+960, 140+960), random.uniform(430, 470), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(170+960, 210+960), random.uniform(430, 470), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(240+960, 280+960), random.uniform(430, 470), 1, random.uniform(0.3, 0.6))
    pag.click(random.uniform(30+960, 70+960), random.uniform(500, 540), 1, random.uniform(0.3, 0.6))
    # 창고 아이템 클릭
    time.sleep(random.uniform(1.55, 2.12))
    pag.click(random.uniform(190+960, 285+960), random.uniform(995, 1015), 1, random.uniform(0.3, 0.6))
    # 꺼내기 버튼 
    time.sleep(random.uniform(1.55, 2.12))
    pag.click(random.uniform(914+960, 939+960), random.uniform(45, 63), 1, random.uniform(0.1, 0.3))
    # 나가기 버튼
    time.sleep(random.uniform(1.001, 1.55))
    pag.click(random.uniform(852+960, 872+960), random.uniform(46, 64), 1, random.uniform(0.1, 0.3))
    # 장비창 열기
    time.sleep(random.uniform(3.001, 4.005))
    pag.click(random.uniform(840+960, 930+960), random.uniform(1000, 1015), 1, 0.5)
    # 자동 장착
    time.sleep(random.uniform(1.55, 2.12))
    pag.click(random.uniform(914+960, 939+960), random.uniform(45, 63), 1, random.uniform(0.1, 0.3))
    # 나가기 버튼
    time.sleep(random.uniform(4.5, 5.5))




